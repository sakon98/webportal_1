<?php
header('Content-Type: text/html; charset=tis-620');
?>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620" />
<?php require "../s/s.Status.php"; ?>
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="right"><strong><font size="4" face="Tahoma">��������ػ�����ҹ�к�</font></strong><br />
    <font color="#FF6600" size="2" face="Tahoma">Status Infomation</font></td>
  </tr>
  <tr>
    <td align="right"><hr color="#999999" size="1"/></td>
  </tr>
</table>
<table width="95%" border="0" align="center" cellpadding="3" cellspacing="6">
  <tr>
    <td width="52%" align="right">�ӹǹ��Ҫԡ���������ŧ����¹ </td>
    <td width="13%" align="center" bgcolor="#CCCCCC"><?=$sum_member?></td>
    <td width="35%" align="left">��</td>
  </tr>
<?php if($confirm2use == 1){	?>
  <tr>
    <td align="right">�ӹǹ��Ҫԡ���͹��ѵԡ����ҹ����</td>
    <td align="center" bgcolor="#CCCCCC"><?=$sum_approve?></td>
    <td align="left">��</td>
  </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td align="left">&nbsp;</td>
  </tr>
  <?php } ?>
</table>
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="right"><strong><font size="4" face="Tahoma">ʶԵԡ��������к�</font></strong><br />
    <font color="#FF6600" size="2" face="Tahoma">Statistics</font></td>
  </tr>
  <tr>
    <td align="right"><hr color="#999999" size="1"/></td>
  </tr>
</table>
<table width="95%" border="0" align="center" cellpadding="3" cellspacing="6">
  <tr>
    <td align="center"><table width="65%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#999999">
    <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
   <?php
			$thaimonth=array("","���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�","��Ȩԡ�¹","�ѹ�Ҥ�");
			GLOBAL $conn;
			$strSQL="SELECT 
							MONTH(date_log) AS LMONTH, YEAR(date_log)+543 AS LYEAR, 
							COUNT(USER) AS LCOUNTFULL ,
							COUNT(DISTINCT USER) AS LCOUNT 
							FROM log_action 
							GROUP BY MONTH(date_log) 
							ORDER BY YEAR(date_log),MONTH(date_log) DESC";
			$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
			$i=0;
			while($objResult = mysql_fetch_array($objQuery)){
				$statmonth[$i] = $objResult['LMONTH'];
				$statyear[$i] = $objResult['LYEAR'];
				$statcountfull[$i] = $objResult['LCOUNTFULL'];
				$statcount[$i] = $objResult['LCOUNT'];
				$i++;
			}
			//count($statmonth);?>

      <tr>
        <td width="36%" height="36" align="center" bgcolor="#0066FF"><strong>��Ш���͹</strong></td>
        <td align="center" bgcolor="#0066FF"><strong>�ӹǹ�����ҹ</strong></td>
        <td align="center" bgcolor="#0066FF"><strong>��Ҫԡ�������к�</strong></td>
        </tr>
                 <?php
			for($i=0;$i<count($statmonth);$i++){
			?>
      <tr>
        <td align="center" bgcolor="#FFFFFF"><?=$thaimonth[intval($statmonth[$i])]?> 
          <?=$statyear[$i]?> </td>
        <td width="30%" align="center" bgcolor="#FFFF99"><table width="65%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="70%" align="right"><?=number_format($statcountfull[$i],0)?></td>
            <td width="30%" align="right">����</td>
          </tr>
        </table></td>
        <td width="30%" align="center" bgcolor="#CCCCCC">
          <table width="65%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="70%" align="right"><?=number_format($statcount[$i],0)?></td>
              <td width="30%" align="right">��</td>
            </tr>
          </table></td>
        </tr>
      <?php } ?>  
    </table>       
        </td>
      </tr>
    </table></td>
  </tr>
</table>
