<?php
session_start();
//header('Content-Type: text/html; charset=tis-620');
require "../include/conf.conn.php";
require "../include/conf.c.php";
$connectby = "desktop";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title><?=$title?></title>
<link rel="shortcut icon" href="../img/logo.png">

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.css">

<!-- Fonts -->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.5.0/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.5.0/css/font-awesome.min.css">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="../js/index.js"></script>
</head>
<body>
<?php if($_REQUEST["usr"] == null or $_REQUEST["pwd"] == null){ ?>
<nav class="navbar navbar-default">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myInverseNavbar2"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <!--<a class="navbar-brand" href="#">Brand</a> -->
      <img src="img/logo.png" width="300" height="48" alt=""/></div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="myInverseNavbar2">
      <ul class="nav navbar-nav navbar-right">
	  <li><a href="description.php"><i class="fa fa-book"></i> �Ը���ҹ�к�</a></li>
        <li><a href="http://www.pbntsc.org/"><i class="fa fa-external-link"></i> ���䫵���ѡ</a></li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
  <div class="container">
    <div class="row">
      <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 hidden-xs">
        <div id="carousel-299058" class="carousel slide">
             <ol class="carousel-indicators">
            <li data-target="#carousel1" data-slide-to="0" class="active"> </li>
           
          </ol>
          <div class="carousel-inner">
            <div class="item active"> <img class="img-responsive"  src="img/img1.jpg"  alt="thumb">
              <!--<div class="carousel-caption" style="position:absolute; top:-25px; color:#FB5B08"><h4>�ˡó���觤� �����Ⱥ�ԡ�� ����������� ������Ҫԡ</h4></div>-->
	</div>
          </div>
          <!--<a class="left carousel-control" href="#carousel-299058" data-slide="prev"><span class="icon-prev"></span></a> <a class="right carousel-control" href="#carousel-299058" data-slide="next"><span class="icon-next"></span></a>--></div>
      </div>
      
        <div class="col-lg-4 col-md-6 col-md-offset-4 col-lg-offset-0">
       <div class="well">
        <h3 class="text-center">ŧ���������ҹ�к�</h3>
        <form name="formID1" method="post" action="" class="form-horizontal" >
          <div class="form-group">
            <label for="username" class="control-label">�Ţ����¹��Ҫԡ</label>
            <div class="input-group">
            <div class="input-group-addon"><i class="fa fa-caret-right"></i></div>
              <input type="text" class="form-control" name="usr" id="usr" required placeholder="��͡�Ţ����¹��Ҫԡ">
            </div>
          </div>
          <div class="form-group">
            <label for="password" class="control-label ">���ʼ�ҹ</label>
            <div class="input-group">
            <div class="input-group-addon"><i class="fa fa-caret-right"></i></span></div>
              <input type="password" class="form-control" name="pwd" id="pwd" required placeholder="��͡���ʼ�ҹ" >
            </div>
          </div>
          <p class="text-center">
          <input type="submit" name="Submit" class="btn btn-primary" role="button" value="�������к�" >
		   <?php if($connection == 0){ ?>
			<a href="register.php" class="btn btn-success" role="button">��Ѥ����ԡ��</a></p><br>
		<?php } ?>
          
        </div>
      </form>
    </div>
    </div>
  </div>

<hr>
<div class="container well">
  <div class="row">
<div class="col-xs-6 col-sm-6 col-lg-3 col-md-3"> <span class="text-right">
      </span>
  <h4>����ö�ʴ�����պ�</h4>
  <hr>
       <!-- Green Progress Bar -->
        <div class="progress">
          <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 85%">Google Chorme</div>
        </div>
        <!-- Blue Progress Bar -->
        <div class="progress">
          <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 82%"> firefox</div>
        </div>
      
        <!-- Red Progress Bar -->
        <div class="progress">
          <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 75%">Internet Exploler 9+</div>
        </div>
</div>
<div class="col-xs-6 col-sm-6 col-lg-4 col-md-4 hidden-sm hidden-xs"> <span class="text-right"> </span>
  <h4>����ǡѺ</h4>
  <hr>
  <div class="media-object-default">
  <div class="media">
  <div class="media-body">�����͡�ҧ����ԡ����Ҫԡ����ö�Դ�����������͹��Ǣͧ�ѭ����Ҫԡ </div>
      
</div>
</div>
</div>
<div class="col-xs-6 col-sm-6 col-lg-5 col-md-5"> <span class="text-right"> </span>
  <h4>�Դ������</h4>
  <hr>

    <address>
      <strong>�ˡó������Ѿ����ྪú�ó�</strong><br>
      116 ������ 2 �Ӻ�����§ ��������ͧ  �ѧ��Ѵྪú�ó� 67000 <br>
     ���Ѿ�� 0-5671-1101,0-5674-4090  ����� 0-5672-1931<br>
  
      </address>
      <address>
			�Ң� 2 ����������ѡ ���Ѿ�� 0-5671-3574 ����� 0-5671-3575
      </address>
	  <address>
			�Ң� 3 ����ͺ֧����ѹ ���Ѿ�� 0-5673-2643  ����� 0-5673-2642
	  </address>
</div>
  </div>
</div>
<footer class="text-center">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <p><?=$credite?></p>
      </div>
    </div>
  </div>
</footer>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.2.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.min.js"></script>
<?php }else{ 
	require "../include/lib.Etc.php";
	require "../include/lib.MySql.php";
	require "../include/lib.Oracle.php";
	require "../lib/login.php";
	 }
 ?>
</body>
</html>